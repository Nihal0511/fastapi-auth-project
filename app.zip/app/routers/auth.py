from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.schemas import UserRegister, UserLogin, TokenOut, UserOut
from app.security import verify_password, create_access_token, hash_password
from app.db import get_db
from app.crud import get_user_by_email, create_user


router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=TokenOut)
def register(user: UserRegister, db: Session = Depends(get_db)):
    # Check if user already exists
    existing = get_user_by_email(db, user.email)
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")

    # Hash password
    hashed_password = hash_password(user.password)

    # Create the new user in DB
    new_user = create_user(db, user.name, user.email, hashed_password)

    # Generate token
    token = create_access_token({"sub": str(new_user.id)})

    # Return TokenOut format
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": new_user  # FastAPI + Pydantic will convert ORM → UserOut
    }


@router.post("/login", response_model=TokenOut)
def login(user_data: UserLogin, db: Session = Depends(get_db)):
    # Get user by email
    user = get_user_by_email(db, user_data.email)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid email or password")

    # Verify password
    if not verify_password(user_data.password, user.password_hash):
        raise HTTPException(status_code=400, detail="Invalid email or password")

    # Generate token
    token = create_access_token({"sub": str(user.id)})

    # Return user + token
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": user
    }
